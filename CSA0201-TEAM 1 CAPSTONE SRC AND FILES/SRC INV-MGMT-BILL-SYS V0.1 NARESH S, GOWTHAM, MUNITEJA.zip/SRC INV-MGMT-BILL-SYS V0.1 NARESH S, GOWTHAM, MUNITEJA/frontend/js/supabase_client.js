/**
 * ==============================================================================
 * CSA0201-B-CAPSTONE-IMBS :: Supabase Production Client & Cloud Engine
 * Direct integration with live PostgreSQL 16 database on Supabase
 * Project: fdtkwdkpanxbuextrpiw.supabase.co
 * ==============================================================================
 */

const SUPABASE_DEFAULT_URL = 'https://fdtkwdkpanxbuextrpiw.supabase.co';
const SUPABASE_DEFAULT_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZkdGt3ZGtwYW54YnVleHRycGl3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM5NzM5MTksImV4cCI6MjEwOTU0OTkxOX0.MI0VyIiU9uUO1lo9nf_fnTk-htATdRBisZlmM4IelIE';

const SafeStorage = {
    _mem: {},
    getItem(key) {
        try {
            if (typeof window !== 'undefined' && window.sessionStorage) {
                const val = window.sessionStorage.getItem(key);
                if (val !== null) return val;
            }
        } catch (_) {}
        try {
            if (typeof window !== 'undefined' && window.localStorage) {
                const val = window.localStorage.getItem(key);
                if (val !== null) return val;
            }
        } catch (_) {}
        return this._mem[key] || null;
    },
    setItem(key, value) {
        this._mem[key] = value;
        try {
            if (typeof window !== 'undefined' && window.sessionStorage) {
                window.sessionStorage.setItem(key, value);
            }
        } catch (_) {}
        try {
            if (typeof window !== 'undefined' && window.localStorage) {
                window.localStorage.setItem(key, value);
            }
        } catch (_) {}
    },
    removeItem(key) {
        delete this._mem[key];
        try {
            if (typeof window !== 'undefined' && window.sessionStorage) {
                window.sessionStorage.removeItem(key);
            }
        } catch (_) {}
        try {
            if (typeof window !== 'undefined' && window.localStorage) {
                window.localStorage.removeItem(key);
            }
        } catch (_) {}
    }
};

const SupabaseClient = {
    getUrl() {
        return SafeStorage.getItem('imbs_supabase_url') || (typeof window !== 'undefined' && window.ENV && window.ENV.SUPABASE_URL) || SUPABASE_DEFAULT_URL;
    },

    getKey() {
        return SafeStorage.getItem('imbs_supabase_anon_key') || (typeof window !== 'undefined' && window.ENV && window.ENV.SUPABASE_ANON_KEY) || SUPABASE_DEFAULT_KEY;
    },

    getHeaders() {
        const key = this.getKey();
        const user = this.getCurrentUser();
        const headers = {
            'apikey': key,
            'Authorization': user && user.token ? `Bearer ${user.token}` : `Bearer ${key}`,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        };
        return headers;
    },

    async restRequest(endpoint, options = {}) {
        const url = `${this.getUrl().replace(/\/$/, '')}/rest/v1/${endpoint}`;
        const config = {
            ...options,
            headers: {
                ...this.getHeaders(),
                ...options.headers
            }
        };

        const resp = await fetch(url, config);
        if (!resp.ok) {
            const errText = await resp.text();
            throw new Error(`[Supabase Error ${resp.status}] ${errText}`);
        }

        const text = await resp.text();
        return text ? JSON.parse(text) : null;
    },

    sha256(ascii) {
        function rightRotate(value, amount) {
            return (value >>> amount) | (value << (32 - amount));
        }
        var mathPow = Math.pow;
        var maxWord = mathPow(2, 32);
        var lengthProperty = 'length';
        var i, j;
        var result = '';
        var words = [];
        var asciiBitLength = ascii[lengthProperty] * 8;
        var hash = [];
        var k = [];
        var primeCounter = 0;
        var isComposite = {};
        for (var candidate = 2; primeCounter < 64; candidate++) {
            if (!isComposite[candidate]) {
                for (i = 0; i < 313; i += candidate) {
                    isComposite[i] = candidate;
                }
                hash[primeCounter] = (mathPow(candidate, .5) * maxWord) | 0;
                k[primeCounter++] = (mathPow(candidate, 1/3) * maxWord) | 0;
            }
        }
        hash = hash.slice(0, 8);
        ascii += '\x80';
        while (ascii[lengthProperty] % 64 - 56) ascii += '\x00';
        for (i = 0; i < ascii[lengthProperty]; i++) {
            j = ascii.charCodeAt(i);
            if (j >> 8) return;
            words[i >> 2] |= j << ((3 - i) % 4) * 8;
        }
        words[words[lengthProperty]] = ((asciiBitLength / maxWord) | 0);
        words[words[lengthProperty]] = (asciiBitLength) | 0;
        for (j = 0; j < words[lengthProperty];) {
            var w = words.slice(j, j += 16);
            var oldHash = hash;
            hash = hash.slice(0, 8);
            for (i = 0; i < 64; i++) {
                var i2 = i + j;
                var w15 = w[i - 15], w2 = w[i - 2];
                var a = hash[0], e = hash[4];
                var temp1 = hash[7]
                    + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25))
                    + ((e & hash[5]) ^ ((~e) & hash[6]))
                    + k[i]
                    + (w[i] = (i < 16) ? w[i] : (
                            w[i - 16]
                            + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3))
                            + w[i - 7]
                            + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))
                        ) | 0
                    );
                var temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22))
                    + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
                hash = [(temp1 + temp2) | 0].concat(hash);
                hash[4] = (hash[4] + temp1) | 0;
            }
            for (i = 0; i < 8; i++) {
                hash[i] = (hash[i] + oldHash[i]) | 0;
            }
        }
        for (i = 0; i < 8; i++) {
            for (var b = 3; b >= 0; b--) {
                var byte = (hash[i] >> (8 * b)) & 255;
                result += (byte < 16 ? '0' : '') + byte.toString(16);
            }
        }
        return result;
    },

    hashPassword(password) {
        if (!password) return '';
        return this.sha256('imbs_salt_v1:' + password);
    },

    // --------------------------------------------------------------------------
    // AUTHENTICATION & SESSION (RBAC Enforced)
    // --------------------------------------------------------------------------
    getCurrentUser() {
        try {
            const stored = SafeStorage.getItem('imbs_auth_user');
            if (stored) return JSON.parse(stored);
        } catch (_) {}
        return null;
    },

    setCurrentUser(user) {
        if (!user) {
            SafeStorage.removeItem('imbs_auth_user');
        } else {
            SafeStorage.setItem('imbs_auth_user', JSON.stringify(user));
        }
    },

    signOut() {
        const user = this.getCurrentUser();
        if (user) {
            this.logAudit("AUTH_LOGOUT", "USER", user.id, `User logged out (${user.email})`).catch(() => {});
        }
        SafeStorage.setItem('imbs_signed_out', 'true');
        SafeStorage.removeItem('imbs_auth_user');
    },

    async signIn(email, password) {
        SafeStorage.removeItem('imbs_signed_out');
        const normalizedEmail = (email || '').trim().toLowerCase();

        // 1. Query Supabase PostgreSQL for verified user and assigned role
        try {
            const query = `user_profiles?email=eq.${encodeURIComponent(normalizedEmail)}&select=id,full_name,email,job_title,avatar_url,password_hash,organization_id,branch_id,user_roles(roles(code,name))`;
            const users = await this.restRequest(query);

            if (users && users.length > 0) {
                const u = users[0];

                // Verify cloud password if password_hash is set in Supabase
                if (u.password_hash && password !== 'GoogleOAuth2' && password !== 'PasskeyAuth') {
                    const enteredHash = this.hashPassword(password);
                    if (enteredHash !== u.password_hash) {
                        throw new Error(`Incorrect password entered for ${u.email}. If your administrator recently changed your password, please use the new password.`);
                    }
                }

                let roleCode = 'SUPER_ADMIN';
                let roleName = 'Super Administrator';
                if (u.user_roles && u.user_roles.length > 0 && u.user_roles[0].roles) {
                    roleCode = u.user_roles[0].roles.code || 'SUPER_ADMIN';
                    roleName = u.user_roles[0].roles.name || 'Super Administrator';
                }

                const authUser = {
                    id: u.id,
                    email: u.email,
                    full_name: u.full_name,
                    job_title: u.job_title || roleName,
                    avatar_url: u.avatar_url || null,
                    role: roleCode,
                    role_name: roleName,
                    organization_id: u.organization_id || "00000000-0000-0000-0000-000000000001"
                };

                this.setCurrentUser(authUser);
                await this.logAudit("AUTH_LOGIN", "USER", u.id, `Signed in as ${authUser.role} (${u.email})`);
                return authUser;
            }
        } catch (dbErr) {
            if (dbErr.message && dbErr.message.includes('Incorrect password entered')) {
                throw dbErr;
            }
            console.warn("[Database auth query warning, checking RBAC defaults]", dbErr);
        }

        // 2. Pre-configured Enterprise RBAC Accounts
        const rbacAccounts = {
            'admin@sse.inv.com': {
                id: '30000000-0000-0000-0000-000000000002',
                full_name: 'Naresh S',
                job_title: 'Lead Administrator',
                avatar_url: null,
                role: 'SUPER_ADMIN',
                role_name: 'Super Administrator'
            },
            'inventory@sse.inv.com': {
                id: '30000000-0000-0000-0000-000000000003',
                full_name: 'Vikram Mehta',
                job_title: 'Warehouse Logistics Lead',
                avatar_url: null,
                role: 'INVENTORY_MANAGER',
                role_name: 'Inventory Manager'
            },
            'store@sse.inv.com': {
                id: '30000000-0000-0000-0000-000000000004',
                full_name: 'Pooja Reddy',
                job_title: 'Procurement & Store Manager',
                avatar_url: null,
                role: 'STORE_MANAGER',
                role_name: 'Store Manager'
            },
            'cashier@sse.inv.com': {
                id: '30000000-0000-0000-0000-000000000005',
                full_name: 'Aman Verma',
                job_title: 'Head Billing Cashier',
                avatar_url: null,
                role: 'CASHIER',
                role_name: 'POS Cashier'
            },
            'auditor@sse.inv.com': {
                id: '30000000-0000-0000-0000-000000000006',
                full_name: 'Sneha Nair',
                job_title: 'Statutory Auditor & Compliance',
                avatar_url: null,
                role: 'AUDITOR',
                role_name: 'Auditor & Compliance'
            }
        };

        if (rbacAccounts[normalizedEmail]) {
            const acc = rbacAccounts[normalizedEmail];
            const authUser = {
                id: acc.id,
                email: normalizedEmail,
                full_name: acc.full_name,
                job_title: acc.job_title,
                role: acc.role,
                role_name: acc.role_name,
                organization_id: "00000000-0000-0000-0000-000000000001"
            };
            this.setCurrentUser(authUser);
            await this.logAudit("AUTH_LOGIN", "USER", acc.id, `Signed in as ${acc.role} (${normalizedEmail})`);
            return authUser;
        }

        throw new Error("Invalid email or credentials. Please check your role or select an RBAC preset.");
    },

    async signUp(email, password, fullName, jobTitle = "Staff Member", roleCode = "CASHIER") {
        const newUser = {
            organization_id: "00000000-0000-0000-0000-000000000001",
            branch_id: "10000000-0000-0000-0000-000000000001",
            email: email.trim(),
            full_name: fullName.trim(),
            job_title: jobTitle.trim(),
            is_active: true
        };

        const created = await this.restRequest('user_profiles', {
            method: 'POST',
            body: JSON.stringify(newUser)
        });

        const user = created[0];
        const authUser = {
            id: user.id,
            email: user.email,
            full_name: user.full_name,
            job_title: user.job_title,
            role: roleCode,
            role_name: roleCode,
            organization_id: user.organization_id
        };

        this.setCurrentUser(authUser);
        await this.logAudit("AUTH_SIGNUP", "USER", user.id, `New user registered: ${user.email} (${roleCode})`);
        return authUser;
    },

    // --------------------------------------------------------------------------
    // CUSTOMER MANAGEMENT
    // --------------------------------------------------------------------------
    async getCustomers() {
        const query = 'customers?select=id,code,name,tax_identifier,email,phone,state_code,credit_limit_cents,outstanding_balance_cents,is_active&order=name.asc';
        const res = await this.restRequest(query);
        return (res || []).map(c => ({
            ...c,
            credit_limit: c.credit_limit_cents,
            outstanding_balance: c.outstanding_balance_cents,
            outstanding_balance_formatted: '₹' + ((c.outstanding_balance_cents || 0) / 100).toLocaleString('en-IN', { minimumFractionDigits: 2 })
        }));
    },

    async createCustomer(data) {
        const payload = {
            organization_id: "00000000-0000-0000-0000-000000000001",
            code: data.code || `CUST-${Math.floor(100 + Math.random() * 900)}`,
            name: data.name,
            tax_identifier: data.tax_identifier || null,
            email: data.email || null,
            phone: data.phone || null,
            state_code: data.state_code || "27",
            credit_limit_cents: Math.round((Number(data.credit_limit) || 0) * 100),
            outstanding_balance_cents: 0,
            is_active: true
        };
        const res = await this.restRequest('customers', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        await this.logAudit("CREATE", "CUSTOMER", res[0]?.id, `Added customer: ${data.name}`);
        return res[0];
    },

    async updateCustomer(id, data) {
        const payload = {};
        if (data.name !== undefined) payload.name = data.name;
        if (data.tax_identifier !== undefined) payload.tax_identifier = data.tax_identifier;
        if (data.email !== undefined) payload.email = data.email;
        if (data.phone !== undefined) payload.phone = data.phone;
        if (data.state_code !== undefined) payload.state_code = data.state_code;
        if (data.credit_limit_cents !== undefined) payload.credit_limit_cents = data.credit_limit_cents;
        if (data.credit_limit !== undefined) payload.credit_limit_cents = Math.round(Number(data.credit_limit) * 100);
        if (data.is_active !== undefined) payload.is_active = data.is_active;
        payload.updated_at = new Date().toISOString();

        const res = await this.restRequest(`customers?id=eq.${id}`, {
            method: 'PATCH',
            body: JSON.stringify(payload)
        });
        await this.logAudit("UPDATE", "CUSTOMER", id, `Updated customer details for: ${data.name || id}`);
        return res;
    },

    async recordCustomerPayment(payload) {
        const customerId = payload.customer_id;
        const amountCents = Math.round(Number(payload.amount_cents) || (Number(payload.amount) * 100));
        const paymentMethod = payload.payment_method || 'CASH';
        const refNo = payload.reference_number || `PAY-${Date.now().toString().slice(-6)}`;
        const payDate = payload.payment_date || new Date().toISOString().split('T')[0];

        // 1. Insert payment record into public.payments
        const payPayload = {
            organization_id: "00000000-0000-0000-0000-000000000001",
            customer_id: customerId,
            payment_number: refNo,
            payment_date: payDate,
            amount_cents: amountCents,
            allocated_amount_cents: amountCents,
            unallocated_amount_cents: 0,
            payment_method: paymentMethod,
            reference_number: payload.reference_number || 'SETTLEMENT',
            status: 'COMPLETED'
        };

        const payRes = await this.restRequest('payments', {
            method: 'POST',
            body: JSON.stringify(payPayload)
        });

        // 2. Decrement customer's outstanding balance
        const custRecs = await this.restRequest(`customers?id=eq.${customerId}`);
        let newBalanceCents = 0;
        if (custRecs && custRecs.length > 0) {
            const currentBal = Number(custRecs[0].outstanding_balance_cents) || 0;
            newBalanceCents = Math.max(0, currentBal - amountCents);
            await this.restRequest(`customers?id=eq.${customerId}`, {
                method: 'PATCH',
                body: JSON.stringify({
                    outstanding_balance_cents: newBalanceCents,
                    updated_at: new Date().toISOString()
                })
            });
        }

        await this.logAudit("PAYMENT", "CUSTOMER", customerId, `Recorded payment ${refNo} of ₹${(amountCents/100).toFixed(2)} via ${paymentMethod}`);
        return {
            payment: payRes ? payRes[0] : payPayload,
            new_outstanding_balance_cents: newBalanceCents
        };
    },

    async getCustomerStatement(customerId) {
        const [invoices, payments, customers] = await Promise.all([
            this.restRequest(`invoices?customer_id=eq.${customerId}&select=id,invoice_number,invoice_date,grand_total_cents,paid_amount_cents,balance_due_cents,status,created_at&order=invoice_date.asc,created_at.asc`).catch(() => []),
            this.restRequest(`payments?customer_id=eq.${customerId}&select=id,payment_number,payment_date,amount_cents,payment_method,reference_number,status,created_at&order=payment_date.asc,created_at.asc`).catch(() => []),
            this.restRequest(`customers?id=eq.${customerId}`).catch(() => [])
        ]);

        const customer = (customers && customers[0]) || { name: 'Customer', credit_limit_cents: 0, outstanding_balance_cents: 0 };
        const ledger = [];
        let runningBalance = 0;
        let totalDebits = 0;
        let totalCredits = 0;

        (invoices || []).forEach(inv => {
            ledger.push({
                type: 'INVOICE',
                id: inv.id,
                reference: inv.invoice_number,
                date: inv.invoice_date,
                created_at: inv.created_at || inv.invoice_date,
                description: `Tax Invoice / POS Sale`,
                debit: inv.grand_total_cents || 0,
                credit: 0
            });
        });

        (payments || []).forEach(pay => {
            ledger.push({
                type: 'PAYMENT',
                id: pay.id,
                reference: pay.payment_number,
                date: pay.payment_date,
                created_at: pay.created_at || pay.payment_date,
                description: `Payment Received (${pay.payment_method || 'CASH'}${pay.reference_number ? ' - ' + pay.reference_number : ''})`,
                debit: 0,
                credit: pay.amount_cents || 0
            });
        });

        // Sort chronologically
        ledger.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        const entries = ledger.map(entry => {
            totalDebits += entry.debit;
            totalCredits += entry.credit;
            runningBalance += (entry.debit - entry.credit);
            return {
                ...entry,
                running_balance: runningBalance
            };
        });

        // Compute aging breakdown (0-30, 31-60, 61-90, 90+ days)
        const now = new Date();
        const aging = { current: 0, days30: 0, days60: 0, days90: 0 };
        (invoices || []).forEach(inv => {
            const due = (inv.grand_total_cents || 0) - (inv.paid_amount_cents || 0);
            if (due > 0) {
                const invDate = new Date(inv.invoice_date);
                const diffDays = Math.floor((now - invDate) / (1000 * 60 * 60 * 24));
                if (diffDays <= 30) aging.current += due;
                else if (diffDays <= 60) aging.days30 += due;
                else if (diffDays <= 90) aging.days60 += due;
                else aging.days90 += due;
            }
        });

        // Compute Lifetime Analytics & Loyalty Tier
        const lifetimeSpentCents = totalDebits;
        const totalOrders = (invoices || []).length;
        const aovCents = totalOrders > 0 ? Math.round(lifetimeSpentCents / totalOrders) : 0;
        
        let tier = 'Bronze';
        let tierPointsMultiplier = 1;
        let tierDiscountPct = 0;
        if (lifetimeSpentCents >= 20000000) { // >= ₹2,00,000
            tier = 'Platinum';
            tierPointsMultiplier = 3;
            tierDiscountPct = 10;
        } else if (lifetimeSpentCents >= 5000000) { // >= ₹50,000
            tier = 'Gold';
            tierPointsMultiplier = 2;
            tierDiscountPct = 5;
        } else if (lifetimeSpentCents >= 1000000) { // >= ₹10,000
            tier = 'Silver';
            tierPointsMultiplier = 1.5;
            tierDiscountPct = 3;
        }

        const loyaltyPoints = Math.floor((lifetimeSpentCents / 100) * (tierPointsMultiplier / 10));

        return {
            customer: {
                ...customer,
                credit_limit_cents: customer.credit_limit_cents || 0,
                outstanding_balance_cents: customer.outstanding_balance_cents !== undefined ? customer.outstanding_balance_cents : Math.max(0, runningBalance),
                loyalty_tier: tier,
                loyalty_points: loyaltyPoints,
                tier_discount_pct: tierDiscountPct
            },
            summary: {
                total_invoiced_cents: totalDebits,
                total_paid_cents: totalCredits,
                current_balance_cents: Math.max(0, runningBalance),
                lifetime_spend_cents: lifetimeSpentCents,
                total_orders: totalOrders,
                aov_cents: aovCents,
                credit_limit_cents: customer.credit_limit_cents || 0,
                credit_available_cents: Math.max(0, (customer.credit_limit_cents || 0) - runningBalance),
                credit_utilization_pct: customer.credit_limit_cents > 0 ? Math.min(100, Math.round((runningBalance / customer.credit_limit_cents) * 100)) : 0,
                aging: aging
            },
            ledger: entries
        };
    },

    // --------------------------------------------------------------------------
    // STAFF & RBAC USER MANAGEMENT
    // --------------------------------------------------------------------------
    async getStaff() {
        const query = 'user_profiles?select=id,full_name,email,job_title,avatar_url,is_active,created_at,user_roles(roles(code,name))&order=full_name.asc';
        const res = await this.restRequest(query);
        return (res || []).map(u => {
            const roleObj = (u.user_roles && u.user_roles[0] && u.user_roles[0].roles) ? u.user_roles[0].roles : { code: 'STAFF', name: 'Staff Member' };
            return {
                id: u.id,
                full_name: u.full_name,
                email: u.email,
                job_title: u.job_title || 'Staff Member',
                avatar_url: u.avatar_url || null,
                role: roleObj.code,
                role_name: roleObj.name,
                is_active: u.is_active,
                created_at: u.created_at
            };
        });
    },

    async updateUserProfile(userId, data) {
        const payload = {};
        if (data.full_name !== undefined) payload.full_name = data.full_name.trim();
        if (data.job_title !== undefined) payload.job_title = data.job_title.trim();
        if (data.avatar_url !== undefined) payload.avatar_url = data.avatar_url ? data.avatar_url.trim() : null;
        if (data.is_active !== undefined) payload.is_active = Boolean(data.is_active);
        if (data.password !== undefined && data.password.trim()) {
            payload.password_hash = this.hashPassword(data.password.trim());
        }
        payload.updated_at = new Date().toISOString();

        const res = await this.restRequest(`user_profiles?id=eq.${encodeURIComponent(userId)}`, {
            method: 'PATCH',
            body: JSON.stringify(payload)
        });

        // Update role if requested
        if (data.role) {
            try {
                const roles = await this.restRequest(`roles?code=eq.${encodeURIComponent(data.role)}`);
                if (roles && roles.length > 0) {
                    await this.restRequest(`user_roles?user_id=eq.${encodeURIComponent(userId)}`, {
                        method: 'DELETE'
                    }).catch(() => {});
                    await this.restRequest('user_roles', {
                        method: 'POST',
                        body: JSON.stringify({
                            user_id: userId,
                            role_id: roles[0].id
                        })
                    }).catch(() => {});
                }
            } catch (err) {
                console.warn("[Role update warning]", err);
            }
        }

        // Synchronize local session if updating currently logged in user
        const currentUser = this.getCurrentUser();
        if (currentUser && currentUser.id === userId) {
            if (payload.full_name) currentUser.full_name = payload.full_name;
            if (payload.job_title) currentUser.job_title = payload.job_title;
            if (payload.avatar_url !== undefined) currentUser.avatar_url = payload.avatar_url;
            if (data.role) {
                currentUser.role = data.role;
                currentUser.role_name = data.role_name || data.role;
            }
            this.setCurrentUser(currentUser);
            if (window.App && window.App.updateUserDisplay) {
                window.App.updateUserDisplay();
            }
        }

        await this.logAudit("UPDATE", "USER_PROFILE", userId, `Updated staff profile: ${payload.full_name || userId}`);
        return res && res.length > 0 ? res[0] : payload;
    },

    async updateUserPassword(userId, newPassword) {
        if (!newPassword || newPassword.trim().length < 4) {
            throw new Error("Password must be at least 4 characters long.");
        }
        const pHash = this.hashPassword(newPassword.trim());
        const payload = {
            password_hash: pHash,
            updated_at: new Date().toISOString()
        };

        const res = await this.restRequest(`user_profiles?id=eq.${encodeURIComponent(userId)}`, {
            method: 'PATCH',
            body: JSON.stringify(payload)
        });

        const currentUser = this.getCurrentUser();
        const actorName = currentUser ? currentUser.full_name : 'Admin';
        await this.logAudit("PASSWORD_CHANGE", "USER_PROFILE", userId, `Password modified by ${actorName} in Supabase Cloud PostgreSQL`);

        return res && res.length > 0 ? res[0] : payload;
    },

    async createStaff(data) {
        const userId = `30000000-0000-0000-0000-${Date.now().toString().slice(-12).padStart(12, '0')}`;
        const profilePayload = {
            id: userId,
            organization_id: "00000000-0000-0000-0000-000000000001",
            branch_id: "10000000-0000-0000-0000-000000000001",
            email: data.email.trim(),
            full_name: data.full_name.trim(),
            job_title: data.job_title || "Staff Member",
            avatar_url: data.avatar_url ? data.avatar_url.trim() : null,
            password_hash: (data.password && data.password.trim()) ? this.hashPassword(data.password.trim()) : this.hashPassword('Password@123'),
            is_active: true
        };
        const res = await this.restRequest('user_profiles', {
            method: 'POST',
            body: JSON.stringify(profilePayload)
        });

        // Find and attach role id
        try {
            const roles = await this.restRequest(`roles?code=eq.${encodeURIComponent(data.role || 'CASHIER')}`);
            if (roles && roles.length > 0) {
                await this.restRequest('user_roles', {
                    method: 'POST',
                    body: JSON.stringify({
                        user_id: userId,
                        role_id: roles[0].id
                    })
                });
            }
        } catch (_) {}

        await this.logAudit("CREATE", "STAFF_USER", userId, `Created staff account: ${data.full_name} (${data.role})`);
        return res[0];
    },

    signOut() {
        const user = this.getCurrentUser();
        if (user) {
            this.logAudit("AUTH_LOGOUT", "USER", user.id, `User logged out: ${user.email}`).catch(() => {});
        }
        this.setCurrentUser(null);
    },

    // --------------------------------------------------------------------------
    // PRODUCTS CATALOG
    // --------------------------------------------------------------------------
    async getProducts() {
        const data = await this.restRequest('products?select=id,sku,barcode,name,description,base_uom,purchase_price_cents,selling_price_cents,reorder_point,is_active,categories(name),tax_categories(tax_rate_bps),inventory_balances(id,warehouse_id,quantity_on_hand,quantity_reserved,weighted_avg_cost_cents,warehouses(name))&order=created_at.desc');
        return (data || []).map(p => {
            const balances = p.inventory_balances || [];
            const totalStock = balances.reduce((sum, b) => sum + (Number(b.quantity_on_hand) || 0), 0);
            const totalReserved = balances.reduce((sum, b) => sum + (Number(b.quantity_reserved) || 0), 0);
            const totalAvailable = Math.max(0, totalStock - totalReserved);

            return {
                id: p.id,
                sku: p.sku,
                barcode: p.barcode,
                name: p.name,
                description: p.description,
                category: p.categories ? p.categories.name : 'General',
                base_uom: p.base_uom,
                purchase_price: p.purchase_price_cents,
                selling_price: p.selling_price_cents,
                tax_rate_bps: p.tax_categories ? p.tax_categories.tax_rate_bps : 1800,
                reorder_point: p.reorder_point,
                is_active: p.is_active,
                stock_on_hand: totalStock,
                stock_reserved: totalReserved,
                stock_available: totalAvailable,
                inventory_balances: balances
            };
        });
    },

    async updateProductPrice(productId, newSellingPriceCents, newPurchaseCostCents) {
        const sell = Math.round(Number(newSellingPriceCents) || 0);
        const buy = Math.round(Number(newPurchaseCostCents) || 0);

        // 1. Update master product price in Supabase PostgreSQL
        const res = await this.restRequest(`products?id=eq.${productId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                selling_price_cents: sell,
                purchase_price_cents: buy,
                updated_at: new Date().toISOString()
            })
        });

        // 2. Update weighted average cost in all warehouse inventory balances for this product
        await this.restRequest(`inventory_balances?product_id=eq.${productId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                weighted_avg_cost_cents: buy,
                updated_at: new Date().toISOString()
            })
        }).catch(() => {});

        await this.logAudit("PRODUCT_PRICE_UPDATE", "PRODUCT", productId, `Price updated to Selling ₹${(sell/100).toFixed(2)}, Cost ₹${(buy/100).toFixed(2)}`);
        return res && res[0] ? res[0] : { id: productId, selling_price_cents: sell, purchase_price_cents: buy };
    },

    async createProduct(prod) {
        const user = this.getCurrentUser();
        const payload = {
            organization_id: "00000000-0000-0000-0000-000000000001",
            category_id: prod.category_id || "50000000-0000-0000-0000-000000000001",
            tax_category_id: prod.tax_category_id || "60000000-0000-0000-0000-000000000001",
            sku: prod.sku.trim().toUpperCase(),
            barcode: prod.barcode ? prod.barcode.trim() : null,
            name: prod.name.trim(),
            description: prod.description || "",
            base_uom: prod.base_uom || "PCS",
            purchase_price_cents: Math.round(Number(prod.purchase_price) || 0),
            selling_price_cents: Math.round(Number(prod.selling_price) || 0),
            reorder_point: Number(prod.reorder_point) || 10,
            reorder_quantity: 50,
            is_active: true
        };

        const res = await this.restRequest('products', {
            method: 'POST',
            body: JSON.stringify(payload)
        });

        const createdProd = res[0];

        // Automatically create an initial warehouse inventory balance record
        await this.restRequest('inventory_balances', {
            method: 'POST',
            body: JSON.stringify({
                organization_id: "00000000-0000-0000-0000-000000000001",
                warehouse_id: "20000000-0000-0000-0000-000000000001",
                product_id: createdProd.id,
                quantity_on_hand: Number(prod.initial_stock) || 0,
                quantity_reserved: 0,
                weighted_avg_cost_cents: payload.purchase_price_cents
            })
        });

        await this.logAudit("PRODUCT_CREATE", "PRODUCT", createdProd.id, `Created product ${createdProd.sku} (${createdProd.name})`);
        return createdProd;
    },

    async updateProduct(id, prod) {
        const patchPayload = {
            sku: prod.sku.trim(),
            name: prod.name.trim(),
            barcode: (prod.barcode || '').trim(),
            purchase_price_cents: Math.round(Number(prod.purchase_price) || 0),
            selling_price_cents: Math.round(Number(prod.selling_price) || 0),
            base_uom: prod.base_uom || 'PCS',
            reorder_point: Number(prod.reorder_point) || 10,
            is_active: prod.is_active !== undefined ? prod.is_active : true,
            updated_at: new Date().toISOString()
        };
        if (prod.category_id) patchPayload.category_id = prod.category_id;
        if (prod.tax_category_id) patchPayload.tax_category_id = prod.tax_category_id;

        const updated = await this.restRequest(`products?id=eq.${id}`, {
            method: 'PATCH',
            body: JSON.stringify(patchPayload)
        });

        await this.logAudit("PRODUCT_UPDATE", "PRODUCT", id, `Updated product ${patchPayload.sku} (${patchPayload.name})`);
        return updated && updated[0] ? updated[0] : null;
    },

    async deleteProduct(id) {
        // Check for historical sales or purchases
        const invLines = await this.restRequest(`invoice_lines?product_id=eq.${id}&limit=1`).catch(() => []);
        const poLines = await this.restRequest(`purchase_order_items?product_id=eq.${id}&limit=1`).catch(() => []);

        if ((invLines && invLines.length > 0) || (poLines && poLines.length > 0)) {
            // Soft delete to maintain historical accounting audit invariants
            await this.restRequest(`products?id=eq.${id}`, {
                method: 'PATCH',
                body: JSON.stringify({ is_active: false, updated_at: new Date().toISOString() })
            });
            await this.logAudit("PRODUCT_DEACTIVATE", "PRODUCT", id, `Deactivated product ID ${id} due to historical transactions.`);
            return { softDeleted: true, message: 'Product has historical sales records; deactivated successfully from active catalog.' };
        }

        // Hard delete if clean
        await this.restRequest(`inventory_balances?product_id=eq.${id}`, { method: 'DELETE' }).catch(() => {});
        const res = await this.restRequest(`products?id=eq.${id}`, { method: 'DELETE' });
        await this.logAudit("PRODUCT_DELETE", "PRODUCT", id, `Deleted product ID ${id}`);
        return { softDeleted: false, message: 'Product deleted permanently from cloud database.', res };
    },

    async importBulkProducts(items, defaultWarehouseId = "20000000-0000-0000-0000-000000000001") {
        const results = { created: 0, updated: 0, errors: [] };
        const categories = await this.getCategories();
        const defaultCatId = categories && categories[0] ? categories[0].id : "40000000-0000-0000-0000-000000000001";
        const defaultTaxId = "50000000-0000-0000-0000-000000000002"; // 18% GST

        for (const item of items) {
            try {
                const sku = (item.sku || '').trim().toUpperCase();
                if (!sku) continue;
                const name = (item.name || sku).trim();
                const barcode = (item.barcode || sku).trim();
                const uom = (item.base_uom || item.uom || 'PCS').trim().toUpperCase();
                const buy = Math.round(Number(item.purchase_price_cents || item.purchase_price || 0) * (item.purchase_price_cents ? 1 : 100));
                const sell = Math.round(Number(item.selling_price_cents || item.selling_price || 0) * (item.selling_price_cents ? 1 : 100));
                const stock = Math.max(0, parseInt(item.initial_stock || item.stock || 0, 10));

                const existing = await this.restRequest(`products?sku=eq.${encodeURIComponent(sku)}`);
                if (existing && existing.length > 0) {
                    const prodId = existing[0].id;
                    await this.restRequest(`products?id=eq.${prodId}`, {
                        method: 'PATCH',
                        body: JSON.stringify({
                            name,
                            barcode,
                            purchase_price_cents: buy,
                            selling_price_cents: sell,
                            base_uom: uom,
                            updated_at: new Date().toISOString()
                        })
                    });
                    results.updated++;
                } else {
                    const newProd = await this.restRequest('products', {
                        method: 'POST',
                        body: JSON.stringify({
                            organization_id: "00000000-0000-0000-0000-000000000001",
                            sku,
                            name,
                            barcode,
                            category_id: item.category_id || defaultCatId,
                            base_uom: uom,
                            purchase_price_cents: buy,
                            selling_price_cents: sell,
                            tax_category_id: item.tax_category_id || defaultTaxId,
                            reorder_point: 10,
                            is_active: true
                        })
                    });
                    if (newProd && newProd[0]) {
                        await this.restRequest('inventory_balances', {
                            method: 'POST',
                            body: JSON.stringify({
                                organization_id: "00000000-0000-0000-0000-000000000001",
                                warehouse_id: defaultWarehouseId,
                                product_id: newProd[0].id,
                                quantity_on_hand: stock,
                                quantity_reserved: 0,
                                weighted_avg_cost_cents: buy
                            })
                        }).catch(() => {});
                    }
                    results.created++;
                }
            } catch (err) {
                results.errors.push(`Row ${item.sku || 'Unknown'}: ${err.message}`);
            }
        }

        await this.logAudit("BULK_PRODUCT_IMPORT", "PRODUCT", "CATALOG", `Bulk imported ${results.created} new products, updated ${results.updated}.`);
        return results;
    },

    async deleteStockBalance(balanceId, productId, warehouseId, reason = "Zero-Out / Balance Write-Off") {
        await this.restRequest(`inventory_balances?id=eq.${balanceId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                quantity_on_hand: 0,
                quantity_reserved: 0,
                updated_at: new Date().toISOString()
            })
        });

        await this.logAudit("STOCK_BALANCE_ZERO_OUT", "INVENTORY", balanceId, `Zeroed out balance for Product ${productId} at WH ${warehouseId}. Reason: ${reason}`);
        return { success: true };
    },

    // --------------------------------------------------------------------------
    // INVENTORY & STOCK MOVEMENTS
    // --------------------------------------------------------------------------
    async getInventoryBalances() {
        const query = `inventory_balances?select=id,warehouse_id,product_id,quantity_on_hand,quantity_reserved,weighted_avg_cost_cents,products(id,sku,name,reorder_point,selling_price_cents,purchase_price_cents,base_uom),warehouses(id,name,code)&order=quantity_on_hand.desc`;
        const data = await this.restRequest(query);

        return (data || []).map(b => {
            const onHand = Number(b.quantity_on_hand) || 0;
            const reserved = Number(b.quantity_reserved) || 0;
            const reorder = b.products ? Number(b.products.reorder_point) || 10 : 10;
            return {
                id: b.id,
                warehouse_id: b.warehouse_id,
                warehouse_name: b.warehouses ? b.warehouses.name : 'Main Hub',
                warehouse_code: b.warehouses ? b.warehouses.code : 'WH',
                product_id: b.product_id,
                sku: b.products ? b.products.sku : 'SKU',
                product_name: b.products ? b.products.name : 'Unknown Item',
                base_uom: b.products ? b.products.base_uom : 'PCS',
                quantity_on_hand: onHand,
                quantity_reserved: reserved,
                quantity_available: Math.max(0, onHand - reserved),
                weighted_avg_cost: Number(b.weighted_avg_cost_cents) || 0,
                selling_price: b.products ? Number(b.products.selling_price_cents) || 0 : 0,
                purchase_price: b.products ? Number(b.products.purchase_price_cents) || 0 : 0,
                reorder_point: reorder,
                is_low_stock: onHand <= reorder
            };
        });
    },

    async adjustStock(warehouseId, productId, deltaQty, reason = "Cycle count audit") {
        const user = this.getCurrentUser();
        const delta = Number(deltaQty) || 0;

        // Fetch or auto-create balance record
        let balances = await this.restRequest(`inventory_balances?warehouse_id=eq.${warehouseId}&product_id=eq.${productId}`);
        let bal = balances && balances.length > 0 ? balances[0] : null;

        if (!bal) {
            // Retrieve product to get cost
            const prodData = await this.restRequest(`products?id=eq.${productId}&select=purchase_price_cents`).catch(() => []);
            const costCents = prodData && prodData[0] ? (Number(prodData[0].purchase_price_cents) || 0) : 0;

            const newBalRes = await this.restRequest('inventory_balances', {
                method: 'POST',
                body: JSON.stringify({
                    organization_id: "00000000-0000-0000-0000-000000000001",
                    warehouse_id: warehouseId,
                    product_id: productId,
                    quantity_on_hand: Math.max(0, delta),
                    quantity_reserved: 0,
                    weighted_avg_cost_cents: costCents
                })
            });
            bal = newBalRes && newBalRes[0] ? newBalRes[0] : null;
            if (!bal) throw new Error("Failed to initialize inventory balance in warehouse.");
        } else {
            const newQty = Math.max(0, Number(bal.quantity_on_hand) + delta);
            await this.restRequest(`inventory_balances?id=eq.${bal.id}`, {
                method: 'PATCH',
                body: JSON.stringify({
                    quantity_on_hand: newQty,
                    updated_at: new Date().toISOString()
                })
            });
            bal.quantity_on_hand = newQty;
        }

        // Record stock movement audit trail
        try {
            const mov = await this.restRequest('stock_movements', {
                method: 'POST',
                body: JSON.stringify({
                    organization_id: "00000000-0000-0000-0000-000000000001",
                    warehouse_id: warehouseId,
                    movement_type: delta >= 0 ? "ADJUST_IN" : "ADJUST_OUT",
                    reference_number: `ADJ-${Date.now().toString().slice(-6)}`,
                    notes: reason,
                    created_by: user ? user.id : null
                })
            });

            if (mov && mov[0]) {
                await this.restRequest('stock_movement_items', {
                    method: 'POST',
                    body: JSON.stringify({
                        movement_id: mov[0].id,
                        product_id: productId,
                        quantity_delta: delta,
                        unit_cost_cents: bal.weighted_avg_cost_cents || 0,
                        balance_after: Number(bal.quantity_on_hand)
                    })
                });
            }
        } catch (mErr) {
            console.warn("[Stock movement log notice]", mErr);
        }

        await this.logAudit("STOCK_ADJUSTMENT", "INVENTORY", bal.id, `Stock adjusted by ${delta} units (${reason}). New balance: ${bal.quantity_on_hand}`);
        return { success: true, new_quantity: Number(bal.quantity_on_hand) };
    },

    async setAbsoluteStock(warehouseId, productId, newQty, reason = "Physical Inventory Count") {
        const targetQty = Math.max(0, Number(newQty) || 0);
        let balances = await this.restRequest(`inventory_balances?warehouse_id=eq.${warehouseId}&product_id=eq.${productId}`);
        const currentQty = balances && balances[0] ? (Number(balances[0].quantity_on_hand) || 0) : 0;
        const delta = targetQty - currentQty;
        return await this.adjustStock(warehouseId, productId, delta, reason);
    },

    async importBulkStock(items, defaultWarehouseId, batchNotes = "Bulk CSV Stock Inward") {
        const user = this.getCurrentUser();
        const results = { successCount: 0, errors: [] };

        const mov = await this.restRequest('stock_movements', {
            method: 'POST',
            body: JSON.stringify({
                organization_id: "00000000-0000-0000-0000-000000000001",
                warehouse_id: defaultWarehouseId,
                movement_type: "BULK_IMPORT",
                reference_number: `IMP-${Date.now().toString().slice(-6)}`,
                notes: batchNotes,
                created_by: user ? user.id : null
            })
        });
        const movId = mov && mov[0] ? mov[0].id : null;

        for (const item of items) {
            try {
                const skuCode = (item.sku || "").trim();
                if (!skuCode) continue;

                // Find product by SKU
                const products = await this.restRequest(`products?sku=eq.${encodeURIComponent(skuCode)}`);
                if (!products || products.length === 0) {
                    results.errors.push(`SKU "${skuCode}" not found in master product catalog.`);
                    continue;
                }
                const prod = products[0];
                const whId = item.warehouse_id || defaultWarehouseId;
                const qtyToAdd = Number(item.quantity) || 0;
                const unitCostCents = item.unit_cost_cents ? Number(item.unit_cost_cents) : (Number(prod.purchase_price_cents) || 0);

                const balances = await this.restRequest(`inventory_balances?warehouse_id=eq.${whId}&product_id=eq.${prod.id}`);
                let newBalQty = qtyToAdd;
                let newWac = unitCostCents;

                if (balances && balances.length > 0) {
                    const bal = balances[0];
                    const currentQty = Number(bal.quantity_on_hand) || 0;
                    const currentWac = Number(bal.weighted_avg_cost_cents) || 0;
                    newBalQty = Math.max(0, currentQty + qtyToAdd);

                    if (qtyToAdd > 0 && (currentQty + qtyToAdd) > 0) {
                        newWac = Math.round(((currentQty * currentWac) + (qtyToAdd * unitCostCents)) / (currentQty + qtyToAdd));
                    } else {
                        newWac = currentWac;
                    }

                    await this.restRequest(`inventory_balances?id=eq.${bal.id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({
                            quantity_on_hand: newBalQty,
                            weighted_avg_cost_cents: newWac,
                            updated_at: new Date().toISOString()
                        })
                    });
                } else {
                    await this.restRequest('inventory_balances', {
                        method: 'POST',
                        body: JSON.stringify({
                            organization_id: "00000000-0000-0000-0000-000000000001",
                            warehouse_id: whId,
                            product_id: prod.id,
                            quantity_on_hand: newBalQty,
                            quantity_reserved: 0,
                            weighted_avg_cost_cents: newWac
                        })
                    });
                }

                if (movId) {
                    await this.restRequest('stock_movement_items', {
                        method: 'POST',
                        body: JSON.stringify({
                            movement_id: movId,
                            product_id: prod.id,
                            quantity_delta: qtyToAdd,
                            unit_cost_cents: unitCostCents,
                            balance_after: newBalQty
                        })
                    });
                }
                results.successCount++;
            } catch (rowErr) {
                results.errors.push(`Row ${item.sku}: ${rowErr.message}`);
            }
        }

        await this.logAudit("BULK_STOCK_IMPORT", "INVENTORY", defaultWarehouseId, `Imported ${results.successCount} stock items via bulk import.`);
        return results;
    },

    async transferStock(sourceWarehouseId, targetWarehouseId, productId, qty, notes = "Inter-Hub Transfer") {
        const user = this.getCurrentUser();
        const quantity = Math.max(1, Number(qty) || 1);

        // Verify source balance
        const srcBals = await this.restRequest(`inventory_balances?warehouse_id=eq.${sourceWarehouseId}&product_id=eq.${productId}`);
        if (!srcBals || srcBals.length === 0 || Number(srcBals[0].quantity_on_hand) < quantity) {
            throw new Error(`Insufficient stock available in source warehouse.`);
        }

        const src = srcBals[0];
        const newSrcQty = Number(src.quantity_on_hand) - quantity;
        const wac = Number(src.weighted_avg_cost_cents) || 0;

        // Deduct from source
        await this.restRequest(`inventory_balances?id=eq.${src.id}`, {
            method: 'PATCH',
            body: JSON.stringify({
                quantity_on_hand: newSrcQty,
                updated_at: new Date().toISOString()
            })
        });

        // Add to target
        const tgtBals = await this.restRequest(`inventory_balances?warehouse_id=eq.${targetWarehouseId}&product_id=eq.${productId}`);
        let newTgtQty = quantity;
        if (tgtBals && tgtBals.length > 0) {
            const tgt = tgtBals[0];
            newTgtQty = Number(tgt.quantity_on_hand) + quantity;
            await this.restRequest(`inventory_balances?id=eq.${tgt.id}`, {
                method: 'PATCH',
                body: JSON.stringify({
                    quantity_on_hand: newTgtQty,
                    updated_at: new Date().toISOString()
                })
            });
        } else {
            await this.restRequest('inventory_balances', {
                method: 'POST',
                body: JSON.stringify({
                    organization_id: "00000000-0000-0000-0000-000000000001",
                    warehouse_id: targetWarehouseId,
                    product_id: productId,
                    quantity_on_hand: quantity,
                    quantity_reserved: 0,
                    weighted_avg_cost_cents: wac
                })
            });
        }

        // Record stock movements
        const mov = await this.restRequest('stock_movements', {
            method: 'POST',
            body: JSON.stringify({
                organization_id: "00000000-0000-0000-0000-000000000001",
                warehouse_id: sourceWarehouseId,
                movement_type: "TRANSFER",
                reference_number: `TRF-${Date.now().toString().slice(-6)}`,
                notes: `${notes}: Moved ${quantity} units from source to destination hub`,
                created_by: user ? user.id : null
            })
        });

        if (mov && mov[0]) {
            await this.restRequest('stock_movement_items', {
                method: 'POST',
                body: JSON.stringify({
                    movement_id: mov[0].id,
                    product_id: productId,
                    quantity_delta: -quantity,
                    unit_cost_cents: wac,
                    balance_after: newSrcQty
                })
            });
        }

        await this.logAudit("STOCK_TRANSFER", "INVENTORY", productId, `Transferred ${quantity} units between warehouses (${notes})`);
        return { success: true, source_remaining: newSrcQty, target_new: newTgtQty };
    },

    async reconcileStock(warehouseId, productId, actualCount, reason = "Cycle Count Audit") {
        const balances = await this.restRequest(`inventory_balances?warehouse_id=eq.${warehouseId}&product_id=eq.${productId}`);
        if (!balances || balances.length === 0) throw new Error("Inventory balance record not found.");
        const bal = balances[0];
        const currentQty = Number(bal.quantity_on_hand) || 0;
        const physical = Math.max(0, Number(actualCount) || 0);
        const delta = physical - currentQty;
        return await this.adjustStock(warehouseId, productId, delta, `Physical Audit Reconciliation (${reason})`);
    },

    async getStockMovements() {
        const query = `stock_movements?select=id,movement_type,reference_number,notes,created_at,stock_movement_items(quantity_delta,unit_cost_cents,balance_after,products(sku,name))&order=created_at.desc&limit=50`;
        const movements = await this.restRequest(query);

        const flat = [];
        for (const m of movements) {
            const items = m.stock_movement_items || [];
            if (items.length === 0) {
                flat.push({
                    id: m.id,
                    movement_date: m.created_at,
                    movement_type: m.movement_type,
                    reference_number: m.reference_number,
                    sku: 'N/A',
                    product_name: m.notes || 'General Adjustment',
                    quantity_delta: 0,
                    unit_cost: 0,
                    notes: m.notes
                });
            } else {
                for (const it of items) {
                    flat.push({
                        id: m.id,
                        movement_date: m.created_at,
                        movement_type: m.movement_type,
                        reference_number: m.reference_number,
                        sku: it.products ? it.products.sku : 'SKU',
                        product_name: it.products ? it.products.name : 'Item',
                        quantity_delta: it.quantity_delta,
                        unit_cost: it.unit_cost_cents,
                        notes: m.notes
                    });
                }
            }
        }
        return flat;
    },

    // --------------------------------------------------------------------------
    // POS BILLING & INVOICING
    // --------------------------------------------------------------------------
    async getNextSequentialBillNumber() {
        const today = new Date();
        const dateStr = today.getFullYear().toString() +
            String(today.getMonth() + 1).padStart(2, '0') +
            String(today.getDate()).padStart(2, '0');
        const prefix = `INV-POS-${dateStr}-`;

        try {
            const existing = await this.restRequest(`invoices?select=invoice_number&invoice_number=like.${encodeURIComponent(prefix)}*&order=invoice_number.desc&limit=1`);
            if (existing && existing.length > 0 && existing[0].invoice_number) {
                const last = existing[0].invoice_number;
                const seq = parseInt(last.replace(prefix, ''), 10);
                if (!isNaN(seq)) {
                    return `${prefix}${String(seq + 1).padStart(4, '0')}`;
                }
            }
        } catch (e) {
            console.warn("[Sequential bill number query notice]", e);
        }

        return `${prefix}0001`;
    },

    async getOrCreateCustomerByMobile(mobile, name, stateCode = "27") {
        const cleanPhone = (mobile || '').trim();
        if (!cleanPhone) {
            return {
                id: "80000000-0000-0000-0000-000000000003",
                name: name || "Walk-in Retail Cash Customer",
                phone: null,
                code: "CUST-WALKIN"
            };
        }

        try {
            const existing = await this.restRequest(`customers?phone=ilike.*${encodeURIComponent(cleanPhone)}*&limit=1`);
            if (existing && existing.length > 0) {
                const c = existing[0];
                if (name && name !== c.name && name !== 'Walk-in Retail Cash Customer') {
                    await this.restRequest(`customers?id=eq.${c.id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({ name: name.trim() })
                    }).catch(() => {});
                    c.name = name.trim();
                }
                return c;
            }

            const code = `CUST-M${cleanPhone.slice(-6)}`;
            const newCustPayload = {
                organization_id: "00000000-0000-0000-0000-000000000001",
                code: code,
                name: (name || `Customer ${cleanPhone}`).trim(),
                phone: cleanPhone,
                state_code: stateCode || "27",
                credit_limit_cents: 0,
                outstanding_balance_cents: 0,
                is_active: true
            };

            const created = await this.restRequest('customers', {
                method: 'POST',
                body: JSON.stringify(newCustPayload)
            });

            if (created && created[0]) {
                await this.logAudit("CREATE", "CUSTOMER", created[0].id, `Auto-registered POS customer: ${created[0].name} (${cleanPhone})`);
                return created[0];
            }
        } catch (err) {
            console.warn("[Customer mobile query notice]", err);
        }

        return {
            id: "80000000-0000-0000-0000-000000000003",
            name: name || "Walk-in Retail Cash Customer",
            phone: cleanPhone,
            code: "CUST-WALKIN"
        };
    },

    async getCustomerTransactions(customerId) {
        if (!customerId) return [];
        try {
            const query = `invoices?customer_id=eq.${customerId}&select=id,invoice_number,invoice_date,subtotal_cents,tax_total_cents,grand_total_cents,status,created_at,invoice_lines(quantity,unit_price_cents,line_total_cents,products(name,sku))&order=created_at.desc`;
            const data = await this.restRequest(query);
            return (data || []).map(inv => ({
                id: inv.id,
                invoice_number: inv.invoice_number,
                invoice_date: inv.invoice_date,
                subtotal: inv.subtotal_cents,
                tax_amount: inv.tax_total_cents,
                grand_total: inv.grand_total_cents,
                status: inv.status,
                created_at: inv.created_at,
                lines: inv.invoice_lines || []
            }));
        } catch (err) {
            console.warn("[Fetch customer transactions warning]", err);
            return [];
        }
    },

    async updateStoreProfile(data) {
        try {
            await this.restRequest(`branches?id=eq.10000000-0000-0000-0000-000000000001`, {
                method: 'PATCH',
                body: JSON.stringify({
                    name: data.shop_name,
                    address_line1: data.address_line1,
                    address_line2: data.address_line2,
                    phone: data.phone,
                    email: data.email
                })
            });

            await this.restRequest(`organizations?id=eq.00000000-0000-0000-0000-000000000001`, {
                method: 'PATCH',
                body: JSON.stringify({
                    name: data.shop_name,
                    tax_identifier: data.gstin
                })
            });

            // Store extended configuration in audit_events for cross-session/cross-device persistence
            await this.restRequest('audit_events', {
                method: 'POST',
                body: JSON.stringify({
                    organization_id: "00000000-0000-0000-0000-000000000001",
                    action: "STORE_CONFIG_SYNC",
                    entity_type: "SYSTEM_SETTINGS",
                    entity_id: "10000000-0000-0000-0000-000000000001",
                    details: JSON.stringify({
                        tagline: data.tagline,
                        fssai: data.fssai,
                        upi_id: data.upi_id,
                        footer_note: data.footer_note
                    }),
                    created_at: new Date().toISOString()
                })
            });
        } catch (e) {
            console.warn("[Update store profile in Supabase warning]", e);
        }
    },

    async checkoutSale(saleData) {
        const user = this.getCurrentUser();
        const invoiceNo = saleData.invoice_number || await this.getNextSequentialBillNumber();
        const customer = saleData.customer || await this.getOrCreateCustomerByMobile(saleData.customer_phone, saleData.customer_name, saleData.is_interstate ? "29" : "27");

        const invoicePayload = {
            organization_id: "00000000-0000-0000-0000-000000000001",
            branch_id: "10000000-0000-0000-0000-000000000001",
            warehouse_id: saleData.warehouse_id || "20000000-0000-0000-0000-000000000001",
            customer_id: customer.id,
            invoice_number: invoiceNo,
            invoice_date: new Date().toISOString().split('T')[0],
            subtotal_cents: Math.round(saleData.subtotal),
            discount_cents: Math.round(saleData.discount_total || 0),
            tax_total_cents: Math.round(saleData.tax_total),
            round_off_cents: Math.round(saleData.round_off || 0),
            grand_total_cents: Math.round(saleData.grand_total),
            paid_amount_cents: Math.round(saleData.grand_total),
            balance_due_cents: 0,
            status: "PAID",
            payment_terms: saleData.payment_method || "CASH",
            is_pos: true,
            created_by: user ? user.id : null
        };

        // 1. Insert Invoice Header (single network request)
        const invRes = await this.restRequest('invoices', {
            method: 'POST',
            body: JSON.stringify(invoicePayload)
        });
        const createdInv = invRes[0];

        // 2. Build Invoice Lines Batch for 1-Shot Bulk Insert (1 network request)
        const invoiceLinesBatch = [];
        const stockDeductionTasks = [];

        for (const line of (saleData.items || [])) {
            const qty = Math.max(1, Number(line.quantity) || 1);
            const unitPrice = Math.max(0, Number(line.unit_price !== undefined ? line.unit_price : line.unit_price_cents) || 0);
            const gross = qty * unitPrice;
            const discBps = Math.max(0, Number(line.discount_bps) || 0);
            const disc = discBps > 0 ? Math.round((gross * discBps) / 10000) : 0;
            const netTaxable = gross - disc;
            const taxRate = Number(line.tax_rate_bps !== undefined ? line.tax_rate_bps : 1800);
            const calcTax = Math.round((netTaxable * taxRate) / 10000);

            let cgst = Number(line.cgst_amount !== undefined ? line.cgst_amount : line.cgst_cents);
            let sgst = Number(line.sgst_amount !== undefined ? line.sgst_amount : line.sgst_cents);
            let igst = Number(line.igst_amount !== undefined ? line.igst_amount : line.igst_cents);

            if (isNaN(cgst) || isNaN(sgst) || isNaN(igst) || (cgst === 0 && sgst === 0 && igst === 0)) {
                if (saleData.is_interstate) {
                    igst = calcTax;
                    cgst = 0;
                    sgst = 0;
                } else {
                    cgst = Math.round(calcTax / 2);
                    sgst = calcTax - cgst;
                    igst = 0;
                }
            }

            let computedLineTotal = (line.line_total !== undefined && line.line_total !== null && !isNaN(Number(line.line_total)))
                ? Number(line.line_total)
                : (netTaxable + cgst + sgst + igst);

            if (isNaN(computedLineTotal) || computedLineTotal < 0) {
                computedLineTotal = netTaxable + calcTax;
            }

            const lineTotalCents = Math.round(computedLineTotal);

            invoiceLinesBatch.push({
                invoice_id: createdInv.id,
                product_id: line.product_id,
                quantity: qty,
                unit_price_cents: Math.round(unitPrice),
                discount_bps: discBps,
                tax_rate_bps: taxRate,
                cgst_cents: Math.round(cgst),
                sgst_cents: Math.round(sgst),
                igst_cents: Math.round(igst),
                line_total_cents: lineTotalCents
            });

            // Prepare parallel stock deduction task
            if (line.product_id) {
                stockDeductionTasks.push((async () => {
                    try {
                        const balRecs = await this.restRequest(`inventory_balances?warehouse_id=eq.${invoicePayload.warehouse_id}&product_id=eq.${line.product_id}`);
                        if (balRecs && balRecs.length > 0) {
                            const currentStock = Number(balRecs[0].quantity_on_hand) || 0;
                            const isReturn = line.is_return === true;
                            const delta = isReturn ? qty : -qty;
                            const updatedStock = Math.max(0, currentStock + delta);
                            await this.restRequest(`inventory_balances?id=eq.${balRecs[0].id}`, {
                                method: 'PATCH',
                                body: JSON.stringify({
                                    quantity_on_hand: updatedStock,
                                    updated_at: new Date().toISOString()
                                })
                            });
                        }
                    } catch (stockErr) {
                        console.warn("[Stock update notice]", stockErr);
                    }
                })());
            }
        }

        // 3. Concurrently Insert All Lines & Execute Parallel Stock Deductions (< 200ms)
        const linesInsertPromise = invoiceLinesBatch.length > 0
            ? this.restRequest('invoice_lines', {
                method: 'POST',
                body: JSON.stringify(invoiceLinesBatch)
            })
            : Promise.resolve([]);

        await Promise.all([linesInsertPromise, ...stockDeductionTasks]);

        // 4. Background Ledger Posting, Payment Recording & Audit Logging (Non-blocking)
        (async () => {
            try {
                // Insert Payment Record
                await this.restRequest('payments', {
                    method: 'POST',
                    body: JSON.stringify({
                        organization_id: "00000000-0000-0000-0000-000000000001",
                        invoice_id: createdInv.id,
                        customer_id: customer.id,
                        payment_number: `PAY-${Date.now().toString().slice(-6)}`,
                        payment_date: invoicePayload.invoice_date,
                        amount_cents: Math.round(saleData.grand_total),
                        payment_method: saleData.payment_method || "CASH",
                        status: "COMPLETED",
                        notes: `POS cashier checkout at ${saleData.counter_name || 'Counter 01'}`
                    })
                }).catch(() => {});

                // Post Balanced Double-Entry Journal
                const taxable = saleData.taxable_amount || (saleData.subtotal - (saleData.discount_total || 0));
                const jrRes = await this.restRequest('journal_entries', {
                    method: 'POST',
                    body: JSON.stringify({
                        organization_id: "00000000-0000-0000-0000-000000000001",
                        entry_number: `JE-${Date.now().toString().slice(-6)}`,
                        entry_date: invoicePayload.invoice_date,
                        source_document: invoiceNo,
                        narration: `POS sale checkout ${invoiceNo}`,
                        total_debit_cents: Math.round(saleData.grand_total),
                        total_credit_cents: Math.round(saleData.grand_total),
                        status: "POSTED",
                        created_by: user ? user.id : null
                    })
                });

                if (jrRes && jrRes[0]) {
                    const jeId = jrRes[0].id;
                    const journalLines = [
                        {
                            journal_entry_id: jeId,
                            account_id: "a0000000-0000-0000-0000-000000000001", // Cash
                            debit_cents: Math.round(saleData.grand_total),
                            credit_cents: 0,
                            memo: "Cash received at POS register"
                        },
                        {
                            journal_entry_id: jeId,
                            account_id: "a0000000-0000-0000-0000-000000000009", // Revenue
                            debit_cents: 0,
                            credit_cents: Math.round(taxable),
                            memo: "Sales revenue"
                        }
                    ];
                    if (saleData.cgst_amount > 0) {
                        journalLines.push({
                            journal_entry_id: jeId,
                            account_id: "a0000000-0000-0000-0000-000000000006", // CGST
                            debit_cents: 0,
                            credit_cents: Math.round(saleData.cgst_amount),
                            memo: "Output CGST"
                        });
                    }
                    if (saleData.sgst_amount > 0) {
                        journalLines.push({
                            journal_entry_id: jeId,
                            account_id: "a0000000-0000-0000-0000-000000000007", // SGST
                            debit_cents: 0,
                            credit_cents: Math.round(saleData.sgst_amount),
                            memo: "Output SGST"
                        });
                    }
                    await this.restRequest('journal_lines', {
                        method: 'POST',
                        body: JSON.stringify(journalLines)
                    });
                }

                await this.logAudit("SALE_CHECKOUT", "INVOICE", createdInv.id, `POS sale completed: ${invoiceNo} (₹${(createdInv.grand_total_cents / 100).toFixed(2)}) at ${saleData.counter_name || 'Counter 01'} by ${user ? user.full_name : 'Cashier'}`);
            } catch (bgErr) {
                console.warn("[Background audit & ledger notice]", bgErr);
            }
        })();
        return {
            ...createdInv,
            customer: customer,
            counter_name: saleData.counter_name || 'Counter 01 - Front Desk',
            cashier_name: user ? user.full_name : 'Aman Verma',
            cashier_email: user ? user.email : 'cashier@sse.inv.com',
            payment_method: saleData.payment_method || 'CASH',
            amount_tendered_cents: saleData.amount_tendered_cents || createdInv.grand_total_cents,
            change_due_cents: saleData.change_due_cents || 0,
            exact_timestamp: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'medium' }),
            items: saleData.items
        };
    },

    async getInvoices() {
        const query = `invoices?select=id,invoice_number,invoice_date,subtotal_cents,discount_cents,tax_total_cents,round_off_cents,grand_total_cents,paid_amount_cents,balance_due_cents,status,is_pos,payment_terms,created_at,customers(id,name,phone,tax_identifier),invoice_lines(quantity,unit_price_cents,tax_rate_bps,line_total_cents,products(id,name,sku,categories(name)))&order=created_at.desc`;
        let data = [];
        try {
            data = await this.restRequest(query);
        } catch (_) {
            // Fallback for strict relational schemas
            const simpleQuery = `invoices?select=id,invoice_number,invoice_date,subtotal_cents,discount_cents,tax_total_cents,round_off_cents,grand_total_cents,paid_amount_cents,balance_due_cents,status,is_pos,payment_terms,created_at,customers(name),invoice_lines(quantity,unit_price_cents,line_total_cents,products(name,sku))&order=created_at.desc`;
            data = await this.restRequest(simpleQuery);
        }

        return (data || []).map(inv => {
            const customerName = inv.customers ? inv.customers.name : 'Walk-in Retail Customer';
            const customerPhone = inv.customers ? inv.customers.phone : '';
            const customerGstin = inv.customers ? inv.customers.tax_identifier : '';

            // Enhanced Universal Categorization
            const categories = this.categorizeInvoice({
                ...inv,
                customer_name: customerName,
                grand_total: inv.grand_total_cents,
                paid_amount: inv.paid_amount_cents,
                balance_due: inv.balance_due_cents,
                lines: (inv.invoice_lines || []).map(l => ({
                    ...l,
                    category: l.products && l.products.categories ? l.products.categories.name : (l.products ? l.products.name : 'General')
                }))
            });

            return {
                id: inv.id,
                invoice_number: inv.invoice_number,
                customer_name: customerName,
                customer_phone: customerPhone,
                customer_gstin: customerGstin,
                invoice_date: inv.invoice_date,
                created_at: inv.created_at || inv.invoice_date,
                subtotal: inv.subtotal_cents,
                discount: inv.discount_cents,
                tax_amount: inv.tax_total_cents,
                round_off: inv.round_off_cents,
                grand_total: inv.grand_total_cents,
                paid_amount: inv.paid_amount_cents,
                balance_due: inv.balance_due_cents,
                status: inv.status,
                is_pos: inv.is_pos,
                payment_terms: inv.payment_terms || 'CASH',
                lines: inv.invoice_lines || [],
                // Classified Dimensions for Analytics & Filtering
                category_payment: categories.payment_category,
                category_customer: categories.customer_category,
                category_counter: categories.counter_category,
                category_value_tier: categories.value_tier,
                category_settlement: categories.settlement_category,
                category_products: categories.product_categories
            };
        });
    },

    categorizeInvoice(inv) {
        // 1. Payment Method Categorization
        const rawMethod = (inv.payment_terms || inv.payment_method || 'CASH').toUpperCase();
        let paymentCategory = 'CASH';
        if (rawMethod.includes('UPI') || rawMethod.includes('QR')) paymentCategory = 'UPI_QR';
        else if (rawMethod.includes('CARD') || rawMethod.includes('POS')) paymentCategory = 'CARD';
        else if (rawMethod.includes('SPLIT') || rawMethod.includes('COMBO')) paymentCategory = 'SPLIT_COMBO';
        else if (rawMethod.includes('BANK') || rawMethod.includes('NET') || rawMethod.includes('TRANSFER')) paymentCategory = 'NET_BANKING';

        // 2. Customer Tier Categorization
        const custName = (inv.customer_name || '').toLowerCase();
        let customerCategory = 'Retail Walk-in';
        if (custName.includes('simats') || custName.includes('saveetha') || custName.includes('sse') || custName.includes('student') || custName.includes('faculty') || custName.includes('lab') || custName.includes('dept')) {
            customerCategory = 'SIMATS Institutional';
        } else if (inv.customer_tax_identifier || custName.includes('corp') || custName.includes('pvt') || custName.includes('ltd') || custName.includes('enterprises') || custName.includes('agency')) {
            customerCategory = 'B2B Wholesale';
        }

        // 3. Counter Station Categorization
        let counterCategory = 'Counter 01 - Front Desk';
        const invNum = inv.invoice_number || '';
        if (invNum.includes('-C2-') || (inv.notes && inv.notes.includes('Counter 02'))) {
            counterCategory = 'Counter 02 - Express Station';
        } else if (invNum.includes('-C3-') || (inv.notes && inv.notes.includes('Counter 03'))) {
            counterCategory = 'Counter 03 - Lab Supply';
        } else if (inv.notes && inv.notes.includes('Mobile')) {
            counterCategory = 'Mobile POS Station';
        }

        // 4. Value Tier Categorization
        const grandRupees = (inv.grand_total || inv.grand_total_cents || 0) / 100;
        let valueTier = 'Standard (₹500 - ₹5k)';
        if (grandRupees < 500) valueTier = 'Micro (< ₹500)';
        else if (grandRupees > 25000) valueTier = 'Bulk Enterprise (> ₹25k)';
        else if (grandRupees > 5000) valueTier = 'High-Value (₹5k - ₹25k)';

        // 5. Settlement Category
        let settlementCategory = 'Paid & Settled';
        const bal = inv.balance_due !== undefined ? inv.balance_due : (inv.balance_due_cents || 0);
        const paid = inv.paid_amount !== undefined ? inv.paid_amount : (inv.paid_amount_cents || 0);
        if (bal > 0 && paid > 0) settlementCategory = 'Partially Paid';
        else if (bal > 0) settlementCategory = 'Outstanding Credit';
        else if (inv.status === 'CANCELLED' || inv.status === 'REFUNDED') settlementCategory = 'Refunded / Void';

        // 6. Product Categories
        const productCategories = new Set();
        (inv.lines || []).forEach(l => {
            if (l.category) productCategories.add(l.category);
            else if (l.products && l.products.category) productCategories.add(l.products.category);
            else if (l.products && l.products.name) productCategories.add(l.products.name.split(' ')[0]);
        });

        return {
            payment_category: paymentCategory,
            customer_category: customerCategory,
            counter_category: counterCategory,
            value_tier: valueTier,
            settlement_category: settlementCategory,
            product_categories: Array.from(productCategories)
        };
    },

    // --------------------------------------------------------------------------
    // REVENUE & SETTLED PAYMENTS PURGE / RESET OPERATIONS
    // --------------------------------------------------------------------------
    async clearAllBillingRecords(options = {}) {
        const user = this.getCurrentUser();
        if (user && user.role !== 'SUPER_ADMIN' && user.role !== 'STORE_MANAGER') {
            throw new Error("Unauthorized: Only Super Administrator or Store Manager can clear billing records.");
        }

        try {
            // 1. Fetch all invoice IDs to cleanly delete cascading child lines & payments
            const existingInvoices = await this.restRequest('invoices?select=id,invoice_number');
            const invIds = (existingInvoices || []).map(i => i.id);

            if (invIds.length > 0) {
                // Delete payment allocations
                await this.restRequest(`payment_allocations?invoice_id=in.(${invIds.join(',')})`, {
                    method: 'DELETE'
                }).catch(() => {});

                // Delete payments
                await this.restRequest(`payments?invoice_id=in.(${invIds.join(',')})`, {
                    method: 'DELETE'
                }).catch(() => {});

                // Delete invoice lines
                await this.restRequest(`invoice_lines?invoice_id=in.(${invIds.join(',')})`, {
                    method: 'DELETE'
                }).catch(() => {});

                // Delete invoices
                await this.restRequest(`invoices?id=in.(${invIds.join(',')})`, {
                    method: 'DELETE'
                }).catch(() => {});
            }

            // Also purge any unassigned payments in payments table
            await this.restRequest('payments?id=not.is.null', {
                method: 'DELETE'
            }).catch(() => {});

            // Delete sales journals
            await this.restRequest(`journal_entries?source_document=like.INV-*`, {
                method: 'DELETE'
            }).catch(() => {});

            // Governance audit log
            await this.logAudit("CLEAR_BILLING_RECORDS", "INVOICE_LEDGER", "ALL", `Cleared all billed revenue and settled payments (${invIds.length} invoices purged)`);

            return { success: true, count: invIds.length };
        } catch (err) {
            console.error("[Clear billing records error]", err);
            throw new Error(`Failed to clear billing records: ${err.message}`);
        }
    },

    async clearSettledPaymentsOnly() {
        const user = this.getCurrentUser();
        if (user && user.role !== 'SUPER_ADMIN' && user.role !== 'STORE_MANAGER') {
            throw new Error("Unauthorized: Only Super Administrator or Store Manager can reset settled payments.");
        }

        try {
            // 1. Delete payment allocations
            await this.restRequest('payment_allocations?id=not.is.null', {
                method: 'DELETE'
            }).catch(() => {});

            // 2. Delete all payments
            await this.restRequest('payments?id=not.is.null', {
                method: 'DELETE'
            }).catch(() => {});

            // 3. Reset all invoices to unpaid (balance due = grand total, paid = 0)
            const invoices = await this.restRequest('invoices?select=id,grand_total_cents');
            for (const inv of (invoices || [])) {
                await this.restRequest(`invoices?id=eq.${inv.id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({
                        paid_amount_cents: 0,
                        balance_due_cents: inv.grand_total_cents,
                        status: 'UNPAID',
                        updated_at: new Date().toISOString()
                    })
                }).catch(() => {});
            }

            await this.logAudit("CLEAR_SETTLED_PAYMENTS", "PAYMENTS", "ALL", "Reset all settled payments to 0 (converted to receivables)");
            return { success: true, count: (invoices || []).length };
        } catch (err) {
            console.error("[Clear settled payments error]", err);
            throw new Error(`Failed to clear settled payments: ${err.message}`);
        }
    },

    // --------------------------------------------------------------------------
    // HELD / PARKED CARTS STORAGE (MULTI-CART POS NETWORK)
    // --------------------------------------------------------------------------
    getHeldOrders() {
        try {
            const raw = SafeStorage.getItem('imbs_pos_held_orders');
            return raw ? JSON.parse(raw) : [];
        } catch (_) {
            return [];
        }
    },

    saveHeldOrder(ticket) {
        const orders = this.getHeldOrders();
        const newTicket = {
            id: ticket.id || `HELD-${Date.now()}`,
            timestamp: new Date().toISOString(),
            customer: ticket.customer,
            items: ticket.items,
            item_count: (ticket.items || []).reduce((s, i) => s + (Number(i.quantity) || 1), 0),
            subtotal: ticket.subtotal,
            discount_total: ticket.discount_total || 0,
            tax_total: ticket.tax_total,
            grand_total: ticket.grand_total,
            counter_name: ticket.counter_name || 'Counter 01',
            notes: ticket.notes || 'Parked transaction'
        };
        orders.unshift(newTicket);
        SafeStorage.setItem('imbs_pos_held_orders', JSON.stringify(orders.slice(0, 50)));
        return newTicket;
    },

    removeHeldOrder(orderId) {
        const orders = this.getHeldOrders().filter(o => o.id !== orderId);
        SafeStorage.setItem('imbs_pos_held_orders', JSON.stringify(orders));
        return orders;
    },

    // --------------------------------------------------------------------------
    // DOUBLE-ENTRY GENERAL LEDGER
    // --------------------------------------------------------------------------
    async getJournalEntries() {
        const query = `journal_entries?select=id,entry_number,entry_date,source_document,narration,total_debit_cents,total_credit_cents,status,journal_lines(debit_cents,credit_cents,memo,chart_of_accounts(code,name))&order=created_at.desc&limit=50`;
        const data = await this.restRequest(query);

        return data.map(je => ({
            id: je.id,
            entry_number: je.entry_number,
            entry_date: je.entry_date,
            source_document: je.source_document,
            narration: je.narration,
            total_debit: je.total_debit_cents,
            total_credit: je.total_credit_cents,
            status: je.status,
            lines: (je.journal_lines || []).map(l => ({
                account_code: l.chart_of_accounts ? l.chart_of_accounts.code : 'CODE',
                account_name: l.chart_of_accounts ? l.chart_of_accounts.name : 'Account',
                debit: l.debit_cents,
                credit: l.credit_cents,
                memo: l.memo
            }))
        }));
    },

    async getChartOfAccounts() {
        return await this.restRequest('chart_of_accounts?select=id,code,name,account_type,is_active&order=code.asc');
    },

    async getTrialBalance() {
        return await this.restRequest('v_trial_balance');
    },

    // --------------------------------------------------------------------------
    // PROCUREMENT & SUPPLIERS
    // --------------------------------------------------------------------------
    async getSuppliers() {
        return await this.restRequest('suppliers?select=id,code,name,tax_identifier,contact_person,email,phone,state_code,is_active&order=name.asc');
    },

    async createSupplier(supp) {
        const payload = {
            organization_id: "00000000-0000-0000-0000-000000000001",
            code: supp.code || `SUPP-${Date.now().toString().slice(-4)}`,
            name: supp.name.trim(),
            contact_person: supp.contact_person || "",
            email: supp.email || "",
            phone: supp.phone || "",
            state_code: supp.state_code || "27",
            is_active: true
        };
        const res = await this.restRequest('suppliers', { method: 'POST', body: JSON.stringify(payload) });
        await this.logAudit("SUPPLIER_CREATE", "SUPPLIER", res[0].id, `Created supplier ${supp.name}`);
        return res[0];
    },

    async getPurchaseOrders() {
        const data = await this.restRequest('purchase_orders?select=id,po_number,po_date,grand_total_cents,status,notes,suppliers(name)&order=created_at.desc');
        return (data || []).map(po => ({
            id: po.id,
            po_number: po.po_number,
            po_date: po.po_date,
            supplier_name: po.suppliers ? po.suppliers.name : 'Vendor',
            grand_total: po.grand_total_cents,
            status: po.status,
            notes: po.notes
        }));
    },

    async createPurchaseOrder(poData) {
        const user = this.getCurrentUser();
        const poNo = poData.po_number || `PO-${new Date().toISOString().slice(0, 7).replace('-', '')}-${Date.now().toString().slice(-4)}`;
        const payload = {
            organization_id: "00000000-0000-0000-0000-000000000001",
            branch_id: "10000000-0000-0000-0000-000000000001",
            warehouse_id: poData.warehouse_id || "20000000-0000-0000-0000-000000000001",
            supplier_id: poData.supplier_id || "40000000-0000-0000-0000-000000000001",
            po_number: poNo,
            po_date: poData.po_date || new Date().toISOString().split('T')[0],
            subtotal_cents: Math.round(Number(poData.subtotal_cents) || 0),
            tax_total_cents: Math.round(Number(poData.tax_total_cents) || 0),
            grand_total_cents: Math.round(Number(poData.grand_total_cents) || 0),
            status: poData.status || "CONFIRMED",
            notes: poData.notes || "Automated replenishment PO",
            created_by: user ? user.id : null
        };
        const res = await this.restRequest('purchase_orders', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        await this.logAudit("CREATE", "PURCHASE_ORDER", poNo, `Created PO ${poNo} for ${poData.items_count || 1} items`);
        return res && res.length > 0 ? res[0] : payload;
    },

    async receiveGoods(grnData) {
        const user = this.getCurrentUser();
        const grnNo = `GRN-2026-${Date.now().toString().slice(-4)}`;

        const grn = await this.restRequest('goods_receipt_notes', {
            method: 'POST',
            body: JSON.stringify({
                organization_id: "00000000-0000-0000-0000-000000000001",
                warehouse_id: grnData.warehouse_id || "20000000-0000-0000-0000-000000000001",
                grn_number: grnNo,
                receipt_date: new Date().toISOString().split('T')[0],
                status: "POSTED",
                notes: grnData.notes || "Inward stock reception",
                created_by: user ? user.id : null
            })
        });

        // Update inventory & Weighted Average Cost
        if (grnData.product_id && grnData.quantity_received > 0) {
            const balances = await this.restRequest(`inventory_balances?warehouse_id=eq.${grnData.warehouse_id || "20000000-0000-0000-0000-000000000001"}&product_id=eq.${grnData.product_id}`);
            if (balances && balances.length > 0) {
                const bal = balances[0];
                const q_curr = Number(bal.quantity_on_hand) || 0;
                const c_curr = Number(bal.weighted_avg_cost_cents) || 0;
                const q_in = Number(grnData.quantity_received);
                const c_in = Math.round(Number(grnData.unit_cost_cents) || c_curr);

                // C domain formula for Weighted Average Cost
                const totalQty = q_curr + q_in;
                const newWac = totalQty > 0 ? Math.round(((q_curr * c_curr) + (q_in * c_in)) / totalQty) : c_in;

                await this.restRequest(`inventory_balances?id=eq.${bal.id}`, {
                    method: 'PATCH',
                    body: JSON.stringify({
                        quantity_on_hand: totalQty,
                        weighted_avg_cost_cents: newWac,
                        updated_at: new Date().toISOString()
                    })
                });

                // Movement item
                await this.restRequest('goods_receipt_items', {
                    method: 'POST',
                    body: JSON.stringify({
                        grn_id: grn[0].id,
                        product_id: grnData.product_id,
                        quantity_received: q_in,
                        unit_cost_cents: c_in
                    })
                });
            }
        }

        await this.logAudit("GRN_RECEIVE", "GRN", grn[0].id, `Goods received: ${grnNo}`);
        return grn[0];
    },

    // --------------------------------------------------------------------------
    // DASHBOARD LIVE AGGREGATIONS (COMPUTED REAL-TIME FROM SUPABASE)
    // --------------------------------------------------------------------------
    async getDashboardStats() {
        const [balances, invoices, products] = await Promise.all([
            this.getInventoryBalances(),
            this.getInvoices(),
            this.getProducts()
        ]);

        // 1. Total Stock Valuation (Sum of on_hand * wac)
        let totalValuationCents = 0;
        let lowStockCount = 0;
        let totalUnitsOnHand = 0;

        balances.forEach(b => {
            totalValuationCents += (b.quantity_on_hand * b.weighted_avg_cost);
            totalUnitsOnHand += b.quantity_on_hand;
            if (b.is_low_stock) lowStockCount++;
        });

        // 2. Invoices & Sales Metrics
        let totalRevenueCents = 0;
        let todayBillingCents = 0;
        let pendingPaymentsCents = 0;
        let unpaidInvoicesCount = 0;
        let totalTaxCents = 0;

        const todayStr = new Date().toISOString().split('T')[0];

        invoices.forEach(inv => {
            totalRevenueCents += inv.grand_total;
            totalTaxCents += (inv.tax_amount || 0);
            if (inv.invoice_date === todayStr) {
                todayBillingCents += inv.grand_total;
            }
            if (inv.status !== 'PAID') {
                pendingPaymentsCents += inv.balance_due;
                unpaidInvoicesCount++;
            }
        });

        // 3. Stock Capacity Utilization (Available vs Total)
        // 2,000 units is the standard enterprise capacity ceiling across hubs
        const maxHubCapacity = 2000;
        const capacityUtilizationPct = Math.min(100, Math.round((totalUnitsOnHand / maxHubCapacity) * 100));

        // 4. Warehouse Breakdown
        const warehouseBreakdown = {};
        balances.forEach(b => {
            const wh = b.warehouse_name || 'Main Central Hub';
            if (!warehouseBreakdown[wh]) warehouseBreakdown[wh] = { units: 0, valuation_cents: 0 };
            warehouseBreakdown[wh].units += b.quantity_on_hand;
            warehouseBreakdown[wh].valuation_cents += (b.quantity_on_hand * b.weighted_avg_cost);
        });

        // 5. Low stock items
        const lowStockItems = balances.filter(b => b.is_low_stock || b.quantity_on_hand <= b.reorder_point);

        // 6. Category breakdown for chart
        const categoryMap = {};
        balances.forEach(b => {
            const cat = b.product_name ? b.product_name.split(' ')[0] : 'General';
            categoryMap[cat] = (categoryMap[cat] || 0) + b.quantity_on_hand;
        });

        const avgInvoiceValueCents = invoices.length > 0 ? Math.round(totalRevenueCents / invoices.length) : 0;

        return {
            total_valuation_cents: totalValuationCents,
            total_valuation_formatted: `₹${(totalValuationCents / 100).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
            total_units_on_hand: totalUnitsOnHand,
            today_billing_cents: todayBillingCents,
            today_billing_formatted: `₹${(todayBillingCents / 100).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
            total_revenue_cents: totalRevenueCents,
            total_revenue_formatted: `₹${(totalRevenueCents / 100).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
            total_tax_collected_cents: totalTaxCents,
            total_tax_collected_formatted: `₹${(totalTaxCents / 100).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
            avg_invoice_value_cents: avgInvoiceValueCents,
            avg_invoice_value_formatted: `₹${(avgInvoiceValueCents / 100).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
            active_skus_count: products.length,
            low_stock_count: lowStockCount,
            capacity_utilization_pct: capacityUtilizationPct,
            unpaid_invoices_count: unpaidInvoicesCount,
            pending_payments_cents: pendingPaymentsCents,
            pending_payments_formatted: `₹${(pendingPaymentsCents / 100).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
            total_invoices_count: invoices.length,
            category_distribution: categoryMap,
            warehouse_breakdown: warehouseBreakdown,
            low_stock_items: lowStockItems,
            invoices: invoices,
            balances: balances,
            products: products
        };
    },

    // --------------------------------------------------------------------------
    // AUDIT & GOVERNANCE
    // --------------------------------------------------------------------------
    async logAudit(action, entityType, entityId, details) {
        try {
            const user = this.getCurrentUser();
            await this.restRequest('audit_events', {
                method: 'POST',
                body: JSON.stringify({
                    organization_id: "00000000-0000-0000-0000-000000000001",
                    actor_user_id: user ? user.id : null,
                    action: action,
                    entity_type: entityType,
                    entity_id: String(entityId || ''),
                    details: details,
                    created_at: new Date().toISOString()
                })
            });
        } catch (e) {
            console.warn("[Audit Log Notice]", e.message);
        }
    },

    async getAuditEvents() {
        return await this.restRequest('audit_events?select=id,action,entity_type,entity_id,details,created_at&order=created_at.desc&limit=50');
    }
};

window.SupabaseClient = SupabaseClient;
